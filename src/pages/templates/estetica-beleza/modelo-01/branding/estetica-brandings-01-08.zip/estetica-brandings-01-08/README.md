# Brandings — Landing Pages de Estética

Pacote com os 8 sistemas de branding:
01 Essenza Natural
02 Lumière Aesthetic
03 Aura Skin
04 Neo Aesthetic
05 Sculpt Body
06 Maison Beauté
07 Clínica 360 Beauty
08 Élite Aesthetics

Cada pasta contém branding.md, tokens.css e README.md.
As 40 imagens coringas devem permanecer em public/images/estetica/shared/.
